/***************************************************************************//**
 * @file
 * @brief Top level application functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef APP_H
#define APP_H

#include "cmu.h"
#include "gpio.h"
#include "capsense.h"
#include "queue.h"
#include "em_emu.h"

#define NEW_HM_TASK_STACK_SIZE 512
#define DIRECTION_TASK_STACK_SIZE 512
#define MONITOR_TASK_STACK_SIZE 512
#define PHYSICS_TASK_STACK_SIZE 512
#define LED_PWM_TASK_STACK_SIZE 512
#define LED_TASK_STACK_SIZE 512
#define LCD_TASK_STACK_SIZE 512
#define IDLE_TASK_STACK_SIZE 512

#define NEW_HM_TASK_PRIO                    21
#define PHYSICS_TASK_PRIO                   28
#define PLATFORM_DIRECTION_TASK_PRIO        23
#define COLLISION_MONITOR_TASK_PRIO         24
#define LED_PWM_TASK_PRIO                   25
#define LED_TASK_PRIO                       26
#define LCD_TASK_PRIO                       27
#define IDLE_TASK_PRIO                      29

enum DATA_FLAGS{
  BOUNDS = 1,
  LASER = 2,
  RESET_HM = 3
};
enum CRASH_FLAGS{
  PHYSICS_TICK = 1,
  ACTIVATE = 2,
  STOP = 4,
  SHIELD_COND = 7
};
enum DEMO_STATE
{
  DEFAULT_STATE,
  NOT_DEFAULT
};
struct initvel
{
  int xvel;
  int yvel;
};
struct CanyonBounce
{
  bool enable;
  bool limited;
  int MaxPlatformBounceSpeed;
};
struct HoltzmanMasses
{
  int Num;//
  int DisplayDiameter;// = 0.2;
  int initialcond;// = 0;
  struct initvel initial_velocity;
  uint32_t initx;// = 20;
  uint32_t userdefinedinput[8];
};

struct Platform
{
  int MaxForce;
  int mass;
  int length;
  struct CanyonBounce MaxSpeed;
  bool Automatic;
};
struct Boost
{
  int KEincrease;
  int ArmingWindow;
  int recharge;
};
struct HoltzmanShield
{
  int minspeed;
  int KEreduction;
  struct Boost boost;
};
struct Laser
{
  int NumActivations;
  bool Auto;
};
struct init_variables{
  int data_struct_ver;// = 3
  int TauPhysics;
  int TauLCD;
  int gravity;// = 2;
  int canyonsize;// = 200;
  struct HoltzmanMasses HM;
  struct Platform Plat;
  struct HoltzmanShield shield;
  struct Laser laser;
};

struct object_t {
    float xpos;
    float ypos;
    float xvel;
    float yvel;
    int mass;
    int force;
    bool plat_or_hm; //1 is plat, 0 is hm
};
/***************************************************************************//**
 * Initialize application.
 ******************************************************************************/
void app_init(void);
void lab_init(void);
void read_button0(void);
void read_button1(void);
void read_capsense(void);
void default_init(void);
void physics(struct object_t *object, int xaccelmode, int yaccel, float ke_change);
void App_TimerCallbackPhysics(void  *p_tmr, void  *p_arg);
void App_TimerCallbackLCD(void  *p_tmr, void  *p_arg);
void App_TimerCallbackSlider(void  *p_tmr, void  *p_arg);
void App_TimerCallbackPWM(void  *p_tmr, void  *p_arg);
void bounds(struct object_t *object, int border);
void reset_hm(struct object_t *object, int *hm_count);
float calc_rled_pwm(float mass, float max_force, float hm_x_init, float hm_y_init, float hm_x_vel, float hm_y_vel, float plat_x_init, float plat_x_vel, float fin_y, float gravity);
float calc_time(float del_y, float vel, float gravity);
#endif  // APP_H
