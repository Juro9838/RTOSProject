#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

struct node_t* create_queue(int btn) {
    // return null so it compiles
    struct node_t *queue_head;
    queue_head = create_new_node(btn);
    return queue_head;
}

struct node_t* create_new_node(int btn) {
    // return null so it compiles
    struct node_t *newnode;
    newnode = malloc(sizeof(struct node_t));
    newnode->btn = btn;
    newnode->next = NULL;
    return newnode;
}

int peek(struct node_t** head) {
    // return null so it compiles
    return (*head)->btn;
}

int pop(struct node_t** head) {
    int btn = 0;
    if(*head)
    {
        struct node_t *temp;
        temp = *head;
        btn = temp->btn;
        *head = temp->next;
        free(temp);
    }
    return btn;
}

void push(struct node_t** head, int btn) {
    struct node_t *temp = *head;
    while(temp->next)
    {
        temp = temp->next;
    }
    temp->next = create_new_node(btn);
}

int is_empty(struct node_t** head) {
    // return 0 so it compiles
    if(*head)
    {
        return 0;
    }
    return 1;
}

void empty_queue(struct node_t** head) {
    while(is_empty(head) == 0)
    {
        pop(head);
    }
}
